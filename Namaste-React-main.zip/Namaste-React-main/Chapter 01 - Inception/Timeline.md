## Episode 01 - Inception

**Detailed Mention of Topics and its Timestamps according to Namaste React Web Series**

```sh
00:05:25 - Visual Code Setup
00:10:00 - Hello World Program by using plain HTML
00:14:25 - Hello World Program using Vanilla JavaScript
00:18:00 - CDN links discussion
00:32:00 - Hello World Program in React
         - Separately writing JS code within <script> tags in HTML
         - React.createElement explanation
00:54:50 - Nested Elements
01:02:00 - Array of children
01:05:00 - Need of JSX
         - Rearrangement of CDN files
01:19:00 - React Library v/s Framework discussion
01:21:00 - Advantages/Specialties of React
01:23:00 - Session Recap
```